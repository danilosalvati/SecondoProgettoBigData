=============
SHOW CATALOGS
=============

Synopsis
--------

.. code-block:: none

    SHOW CATALOGS

Description
-----------

List the available catalogs.
