==============
SHOW FUNCTIONS
==============

Synopsis
--------

.. code-block:: none

    SHOW FUNCTIONS

Description
-----------

List all the functions available for use in queries.
