==============
Stage Resource
==============

.. function:: GET /v1/stage

   Returns detail about a stage in a Presto query.

.. function:: DELETE /v1/stage/{stageId}

   Deletes a stage in a Presto query.
