============
SHOW COLUMNS
============

Synopsis
--------

.. code-block:: none

    SHOW COLUMNS FROM table

Description
-----------

List the columns in ``table`` along with their data type and other attributes.
