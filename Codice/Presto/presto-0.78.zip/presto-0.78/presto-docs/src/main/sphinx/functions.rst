***********************
Functions and Operators
***********************

.. toctree::
    :maxdepth: 1

    functions/logical
    functions/comparison
    functions/conditional
    functions/conversion
    functions/math
    functions/string
    functions/binary
    functions/datetime
    functions/regexp
    functions/json
    functions/url
    functions/aggregate
    functions/window
    functions/color
    functions/array
    functions/map
