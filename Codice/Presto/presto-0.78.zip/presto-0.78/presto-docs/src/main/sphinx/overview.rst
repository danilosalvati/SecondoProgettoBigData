********
Overview
********

Presto is a distributed SQL query engine designed to query large data sets
distributed over one or more heterogeneous data sources.

.. toctree::
    :maxdepth: 1

    overview/use-cases
