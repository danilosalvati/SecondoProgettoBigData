============
Release 0.62
============

* Fix an issue with active queries JMX counter reporting incorrect numbers

* Hive binary map keys were not being decoded correctly

* Performance improvements for ``APPROX_DISTINCT``

* Fix performance regression when planning queries over a large number of partitions

* Minor improvement to coordinator UI when displaying long SQL queries
