============
Release 0.63
============

* Minor improvements to coordinator UI

* Minor planner optimization to avoid redundant computation in some cases

* Error handling and classification improvements
