==========
USE SCHEMA
==========

Synopsis
--------

.. code-block:: none

    USE SCHEMA schema

Description
-----------

Update the session to use the specified schema
