============
Release 0.72
============

* Fix infinite loop bug in Hive RCFile reader when decoding a Map
  with a null key
