************
Installation
************

.. toctree::
    :maxdepth: 1

    installation/deployment
    installation/cli
    installation/jdbc
    installation/verifier
