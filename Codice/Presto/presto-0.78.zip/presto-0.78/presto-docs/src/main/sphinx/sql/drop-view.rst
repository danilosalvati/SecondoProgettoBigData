=========
DROP VIEW
=========

Synopsis
--------

.. code-block:: none

    DROP VIEW view_name

Description
-----------

Drop an existing view.

Examples
--------

Drop the view ``orders_by_date``::

    DROP VIEW orders_by_date
