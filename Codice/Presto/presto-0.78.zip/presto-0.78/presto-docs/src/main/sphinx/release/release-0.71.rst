============
Release 0.71
============

* Fix packaging issue that resulted in an unusable server tarball
  for the 0.70 release

* Fix logging in Hive connector when using Amazon S3
