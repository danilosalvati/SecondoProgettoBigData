============
Release 0.65
============

* Fix ``NullPointerException`` when tearing down queries

* Fix exposed third-party dependencies in JDBC driver JAR
