*************
Release Notes
*************

.. toctree::
    :maxdepth: 1

    release/release-0.78
    release/release-0.77
    release/release-0.76
    release/release-0.75
    release/release-0.74
    release/release-0.73
    release/release-0.72
    release/release-0.71
    release/release-0.70
    release/release-0.69
    release/release-0.68
    release/release-0.67
    release/release-0.66
    release/release-0.65
    release/release-0.64
    release/release-0.63
    release/release-0.62
    release/release-0.61
    release/release-0.60
    release/release-0.59
    release/release-0.58
    release/release-0.57
    release/release-0.56
    release/release-0.55
    release/release-0.54
