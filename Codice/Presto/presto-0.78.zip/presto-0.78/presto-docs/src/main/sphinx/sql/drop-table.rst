==========
DROP TABLE
==========

Synopsis
--------

.. code-block:: none

    DROP TABLE table_name

Description
-----------

Drops an existing table

Examples
--------

Drop a table ``orders_by_date``::

    DROP TABLE orders_by_date

