DROP TABLE IF EXISTS presto_test_s3;
