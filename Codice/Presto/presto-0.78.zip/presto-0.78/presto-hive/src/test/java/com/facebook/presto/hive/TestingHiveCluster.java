/*
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *     http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.facebook.presto.hive;

import com.facebook.presto.hive.shaded.org.apache.thrift.transport.TTransportException;
import com.google.common.base.Objects;
import com.google.common.base.Throwables;

import static com.google.common.base.Preconditions.checkNotNull;

public class TestingHiveCluster
        implements HiveCluster
{
    private final HiveClientConfig config;
    private final String host;
    private final int port;

    public TestingHiveCluster(HiveClientConfig config, String host, int port)
    {
        this.config = checkNotNull(config, "config is null");
        this.host = checkNotNull(host, "host is null");
        this.port = port;
    }

    @Override
    public HiveMetastoreClient createMetastoreClient()
    {
        try {
            return new HiveMetastoreClientFactory(config).create(host, port);
        }
        catch (TTransportException e) {
            throw Throwables.propagate(e);
        }
    }

    @Override
    public boolean equals(Object obj)
    {
        if (this == obj) {
            return true;
        }
        if ((obj == null) || (getClass() != obj.getClass())) {
            return false;
        }
        TestingHiveCluster o = (TestingHiveCluster) obj;

        return Objects.equal(this.host, o.host) &&
                Objects.equal(this.port, o.port);
    }

    @Override
    public int hashCode()
    {
        return Objects.hashCode(host, port);
    }
}
